﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Austin Siegel's Copy
namespace CreateClassesObjs 
{ 
    public class Course 
    {        
        // Private field to hold the name of the course
        private string name;      
        
        // Method to set the name of the course
        public void setName(string name)        
        {            
            this.name = name;        
        }

        // Method to retrieve the name of the course
        public string getName()        
        {            
            return this.name;        
        }

        // Overriding the ToString() method to return the name of the course
        public override string ToString()        
        {            
            // this method should return the name field
            return this.name;        
        }    
    }
}
